// firebase-config.js
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.9.1/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/11.9.1/firebase-analytics.js";
import { getDatabase } from "https://www.gstatic.com/firebasejs/11.9.1/firebase-database.js";

const firebaseConfig = {
  apiKey: "AIzaSyDMf3fOnS2vAjsnplbzMfzlZXpIG0Pz5l4",
  authDomain: "axp-mods-v2.firebaseapp.com",
  databaseURL: "https://axp-mods-v2-default-rtdb.firebaseio.com",
  projectId: "axp-mods-v2",
  storageBucket: "axp-mods-v2.firebasestorage.app",
  messagingSenderId: "1053333155104",
  appId: "1:1053333155104:web:0f48fb4a0c73e03ea2bb45",
  measurementId: "G-YQ6W8KX9DB"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const db = getDatabase(app);

// Export the initialized services
export { app, analytics, db };